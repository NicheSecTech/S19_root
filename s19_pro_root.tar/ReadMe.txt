How to hack the Antminer S19 Pro.

Copy the archive file over to the device, login, then run the following commands.

# cat s19_pro_rooter.tar|ssh miner@192.168.2.95 "cat >/tmp/s19_pro_rooter.tar"
# ssh miner@192.168.2.95
Password: miner
miner@S19PRO-01$ ~ cd /tmp/
miner@S19PRO-01$ /tmp tar -xf s19_files.tar
miner@S19PRO-01$ /tmp chmod +x *.sh
miner@S19PRO-01$ /tmp /tmp/ownit.sh
