#!/bin/sh
echo "Setting the write backs to zero..."
echo 0 > /proc/sys/vm/dirty_writeback_centisecs

echo "Setting up modified busybox files in /tmp/miner/ ..."
cp -f /bin/busybox /tmp/miner/busybox
mv /tmp/busybox-armv7l /tmp/miner/busybox2
chmod 4755 /tmp/miner/busybox
chmod 4755 /tmp/miner/busybox2
chown root.root /tmp/miner/busybox
chown root.root /tmp/miner/busybox2
chmod u+s /tmp/miner/busybox
chmod u+s /tmp/miner/busybox2

echo "Copying modified passwd file..."
cp -f /tmp/passwd /config/passwd
chown root.root /config/passwd
chmod 644 /config/passwd

echo "Done."
ls -al /tmp/miner/busybox*

